/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

/**
 *
 * @author ASUS
 */
import Model.AddOrder;
import java.sql.SQLException;
public class OrderController {
    public static void addOrder(int orderId,int quantity ,String prdctName, String cusName)
                 throws SQLException {
        AddOrder addOrder = new AddOrder();
        addOrder.addOrder(orderId,quantity ,prdctName,cusName );
    }
}
