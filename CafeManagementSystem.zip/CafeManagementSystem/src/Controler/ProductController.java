/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

import Model.AddProduct;
import java.sql.SQLException;

/**
 *
 * @author ASUS
 */
public class ProductController {
    
    public static void addProduct(int pID, String pName, String price)
                 throws SQLException {
        AddProduct addProduct = new AddProduct();
        addProduct.addProduct(pID, pName,price);
    }
         
}
