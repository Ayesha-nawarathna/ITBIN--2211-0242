/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controler;

/**
 *
 * @author ASUS
 */
import Model.AddCustomer;
import Model.RemoveCustomer;
import Model.RemoveOrder;
import java.sql.SQLException;

public class CustomerController {
    public static void addCustomer(int cId, String cName, int cont)
                 throws SQLException {
        AddCustomer addCustomer = new AddCustomer();
        addCustomer.addCustomer(cId, cName,cont);
}

    public void removeCustomer(int cId) throws SQLException {
        RemoveCustomer.removeCustomer(cId);
    }

    public void removeOrder(int orderId) throws SQLException {
        RemoveOrder.removeOrder(orderId);
    }

    

}