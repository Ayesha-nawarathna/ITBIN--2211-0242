/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

/**
 *
 * @author ASUS
 */
public class RemoveOrder {
    
    public static void removeOrder(int orderId) throws SQLException {
        String sql = "DELETE FROM orders WHERE orderId = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, orderId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No account found with customer ID: " + orderId);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing Customer: " + e.getMessage(), e);
        }
    }
}
