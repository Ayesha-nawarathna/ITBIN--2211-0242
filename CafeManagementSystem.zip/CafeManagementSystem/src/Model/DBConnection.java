/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author ASUS
 */
 public class DBConnection {
   
    private static Connection conn;
    private static Statement stat;
    private static final String URL = "jdbc:mysql://localhost:3306/caffeedb";
    private static final String USER = "root"; 
    private static final String PASSWORD = ""; 
   
public static Statement getStatementConnection() {
         try {
//Establish the connection
         String url = "jdbc:mysql://localhost:3306/bankdbs";
         conn = DriverManager.getConnection(url, "root", "");
//Create the connection
            stat = conn.createStatement();
       
        } catch (SQLException e) {
        }
           return stat;
        }
    //Close the connection
public static void closeCon() throws SQLException {
        conn.close();
    }

    static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
       
    }

    static Connection conn() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public PreparedStatement preparedStatement() throws SQLException {
        if (conn == null || conn.isClosed()) {
            getConnection();
        }
        String query = null;
        return conn.prepareStatement(query);
    }

    public PreparedStatement preparedStatement(String select__from_account) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
    
