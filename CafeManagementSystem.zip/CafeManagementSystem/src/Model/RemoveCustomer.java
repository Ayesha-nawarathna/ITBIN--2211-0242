/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ASUS
 */
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class RemoveCustomer {
    

    
     public static void removeCustomer(int cId) throws SQLException {
        String sql = "DELETE FROM customers WHERE customerId = ?";

        try (Connection conn = DBConnection.getConnection(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cId);
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected == 0) {
                throw new SQLException("No account found with customer ID: " + cId);
            }
        } catch (SQLException e) {
            throw new SQLException("Error removing Customer: " + e.getMessage(), e);
        }
    }
    }

    
   

